async function loadStudents() {
    const students = await fetch(`${url}/api/student/getAll`).then(response => response.json())
    return students
}

function selectStudent(id) {
    sessionStorage.setItem('studentId', id)
    window.location.assign('../student')
}