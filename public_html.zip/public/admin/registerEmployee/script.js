async function register(event) {
    event.preventDefault()
    const { name, username, password } = event.target
    const result = document.getElementById('result')
    const employee = {
        name: name.value,
        username: username.value,
        password: password.value
    }

    result.innerHTML = 'Carregando...'
    const response = await fetch(`${url}/api/auth/register`, {
        method: "POST",
        headers: { "Content-type": "application/json" },
        body: JSON.stringify(employee)
    }).then(data => data.json())
    if (response) {
        sessionStorage.setItem('token', response.token)
        sessionStorage.setItem('employee', response.employee)
        result.innerHTML = response.token
    } else {
        result.innerHTML = 'Não deu'
    }
}