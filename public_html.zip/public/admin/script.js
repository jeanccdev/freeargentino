async function login(event) {
    event.preventDefault()
    const { username, password } = event.target
    const result = document.getElementById('result')
    const employee = {
        username: username.value,
        password: password.value
    }

    result.innerHTML = 'Carregando...'
    const response = await fetch(`${url}/api/auth/login`, {
        method: "POST",
        headers: { "Content-type": "application/json" },
        body: JSON.stringify(employee)
    }).then(data => data.json())

    if (response) {
        sessionStorage.setItem('token', response.token)
        sessionStorage.setItem('employeeId', response.employee.id)
        window.location.assign(`listStudent/`)
    } else {
        result.innerHTML = 'Não deu'
    }
}