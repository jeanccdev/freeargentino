async function createStudent(event) {
    event.preventDefault()
    const { firstName, lastName, rg, cpf, countryBirth, state, birthdate } = event.target
    const result = document.getElementById('result')
    const student = {
        firstName: firstName.value,
        lastName: lastName.value,
        rg: rg.value,
        cpf: cpf.value,
        countryBirth: countryBirth.value,
        state: state.value,
        birthdate: birthdate.value
    }

    result.innerHTML = 'Carregando...'
    const response = await fetch(`${url}/api/student/insertOne`, {
        method: "POST",
        headers: { "Content-type": "application/json" },
        body: JSON.stringify(student)
    }).then(data => data.json())
    
    response ? result.innerHTML = 'Estudante cadastrado com sucesso' : 'Erro ao cadastrar o estudante'
}