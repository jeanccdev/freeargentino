async function checkStudent(event) {
    event.preventDefault()
    const cpf = event.target.elements.cpf.value
    const student = await fetch(`${url}/api/student/getCpf/${cpf}`).then(response => response.json())
    if (student) {
        sessionStorage.setItem('token', student.token)
        sessionStorage.setItem('id', student.student.id)
        window.location.assign(`student/`)
    } else {
        document.getElementById('erro').innerHTML = 'Estudante não encontrado'
    }
    console.log(student)
}