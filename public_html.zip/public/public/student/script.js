async function fetchStudent() {
    const studentId = sessionStorage.getItem('id')
    const student = await fetch(`${url}/api/student/getId/${studentId}`).then(response => response.json())
    console.log(student)
    return student
}

async function fetchDocuments() {
    const token = sessionStorage.getItem('token')
    const studentId = sessionStorage.getItem('id')
    const documents = await fetch(`${url}/api/document/getDocuments/${studentId}`, {
        headers: { Authorization: `Bearer ${token}` }
    }).then(response => response.json())
    console.log(documents)
    return documents
}